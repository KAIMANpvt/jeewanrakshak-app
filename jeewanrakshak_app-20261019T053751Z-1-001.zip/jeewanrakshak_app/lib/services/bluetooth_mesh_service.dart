// Demo ke liye dummy - actual me flutter_bluetooth_serial lagega
class BluetoothMeshService {
  static void broadcastSOS(String token){
    print("BLE Broadcast: $token");
  }
}