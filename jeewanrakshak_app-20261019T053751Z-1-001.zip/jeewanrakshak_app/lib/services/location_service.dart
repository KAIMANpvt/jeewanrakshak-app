import 'package:geolocator/geolocator.dart';

class LocationService {
  // Purana naam aur naya naam dono daal diye, ab kahin bhi error nahi ayega
  Future<Position> getCurrentLocation() async => await getLocation();
  Future<Position> getCurrentPosition() async => await getLocation();

  Future<Position> getLocation() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) await Geolocator.openLocationSettings();
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }
}