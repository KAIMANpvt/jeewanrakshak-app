import 'package:supabase_flutter/supabase_flutter.dart';
import 'location_service.dart';
import 'package:geocoding/geocoding.dart'; // NEW

class SOSService {
  final supa = Supabase.instance.client;

  // NEW FUNCTION: Lat/Lng se City nikalna
  Future<String> getCityFromLocation(double lat, double lon) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(lat, lon);
      if (placemarks.isNotEmpty) {
        // Pehle locality (city), nahi toh subAdministrativeArea
        return placemarks[0].locality??
               placemarks[0].subAdministrativeArea??
               placemarks[0].administrativeArea??
               'Unknown';
      }
    } catch (e) {
      print("City detect error: $e");
    }
    return 'Unknown';
  }

  Future<String> triggerSOS({String? triggerType, String? type, String message = ''}) async {
    final user = supa.auth.currentUser;
    if (user == null) throw Exception("User login nahi hai");

    // Spam protection - same
    final last = await supa.from('sos_requests').select('created_at').eq('user_id', user.id).order('created_at', ascending: false).limit(1).maybeSingle();
    if (last!= null) {
      final diff = DateTime.now().difference(DateTime.parse(last['created_at']));
      if (diff.inMinutes < 2) {
        throw Exception("Help aa rahi hai, 2 min ruko!");
      }
    }

    final pos = await LocationService().getLocation();

    // FIX: AUTOMATIC CITY DETECT - Rajkot hat gaya
    String cityName = await getCityFromLocation(pos.latitude, pos.longitude);
    print("Auto detected city: $cityName"); // Debug ke liye

    final req = await supa.from('sos_requests').insert({
      'user_id': user.id,
      'type': triggerType?? type?? 'medical',
      'status': 'pending',
      'latitude': pos.latitude,
      'longitude': pos.longitude,
      'city': cityName, // AB AUTOMATIC
      'message': message,
    }).select().single();

    return req['id'].toString();
  }

  Future<void> acceptSOS(String sosId) async {
    await supa.from('sos_accepts').insert({
      'sos_id': sosId,
      'helper_id': supa.auth.currentUser?.id,
    });
    try {
      await supa.from('sos_requests').update({'status': 'accepted'}).eq('id', sosId);
    } catch (e) {
      print("Status update error: $e");
    }
  }

  Future<List> getNearbySOS() async {
    final pos = await LocationService().getLocation();
    return await supa.from('sos_requests')
     .select()
     .eq('status', 'pending')
     .neq('user_id', supa.auth.currentUser!.id)
     .gte('latitude', pos.latitude - 0.018)
     .lte('latitude', pos.latitude + 0.018)
     .gte('longitude', pos.longitude - 0.018)
     .lte('longitude', pos.longitude + 0.018);
  }
}