import 'sos_service.dart';

class WomenSafetyService {
  void startShakeSOS() {
    // Ab shake nahi chahiye, isliye package ki zarurat nahi
    print("Women Safety Started");
  }
}