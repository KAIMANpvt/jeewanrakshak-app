import 'sos_service.dart';

class VoiceDetectionService {
  // Tu speech_to_text plugin use kar raha hoga
  void onVoiceHeard(String text) {
    if (text.toLowerCase().contains("bachao") || 
        text.toLowerCase().contains("help") ||
        text.toLowerCase().contains("save me")) {
      SOSService().triggerSOS(type: 'women_safety', message: 'Voice trigger: $text');
    }
  }
}