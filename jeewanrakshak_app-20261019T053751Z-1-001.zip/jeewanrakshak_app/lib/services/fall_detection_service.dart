import 'package:sensors_plus/sensors_plus.dart';
import 'sos_service.dart';

class FallDetectionService {
  void start() {
    accelerometerEventStream().listen((event) {
      double g = (event.x*event.x + event.y*event.y + event.z*event.z);
      if(g > 400){
        SOSService().triggerSOS(triggerType: 'accident');
      }
    });
  }
}