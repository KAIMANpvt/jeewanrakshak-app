import 'package:flutter_local_notifications/flutter_local_notifications.dart';
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
  }
  static show(String title, String body) async {
    await _plugin.show(0, title, body, const NotificationDetails(android: AndroidNotificationDetails('jeewan', 'JeewanRakshak', importance: Importance.max)));
  }
}