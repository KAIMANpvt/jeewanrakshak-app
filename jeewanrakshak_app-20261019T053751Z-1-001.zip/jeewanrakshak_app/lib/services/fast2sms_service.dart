import 'package:geolocator/geolocator.dart';

class Fast2SMSService {
  Future<void> sendWomenSafetyAlert(Position pos) async {
    String mapsLink = "https://www.google.com/maps/search/?api=1&query=${pos.latitude},${pos.longitude}";
    String msg = "ALERT! Your contact is UNSAFE! Women Safety SOS triggered. Location: $mapsLink - JeewanRakshak";
    print(msg); // Yaha tera Fast2SMS API call ayega
    // TODO: Add your Fast2SMS API key call from backend/server.js
  }
}