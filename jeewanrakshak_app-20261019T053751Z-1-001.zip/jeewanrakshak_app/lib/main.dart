import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'screens/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://cwhvobtwsunsraekhjvq.supabase.co',
    publishableKey: 'sb_publishable__cQohmt2Qr3A6eprOljCcg_dI7Xqzvz',
  );
  runApp(const JeewanRakshakApp());
}

class JeewanRakshakApp extends StatelessWidget {
  const JeewanRakshakApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: const Color(0xFFD50000),
      ),
      home: const LoginScreen(),
    );
  }
}