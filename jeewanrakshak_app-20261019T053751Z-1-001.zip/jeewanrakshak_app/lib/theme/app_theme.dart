import 'package:flutter/material.dart';
final jeewanTheme = ThemeData(
  scaffoldBackgroundColor: Colors.black,
  primaryColor: Color(0xFFD50000),
  colorScheme: ColorScheme.dark(primary: Color(0xFFD50000)),
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: Color(0xFFD50000),
      foregroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
    )
  )
);