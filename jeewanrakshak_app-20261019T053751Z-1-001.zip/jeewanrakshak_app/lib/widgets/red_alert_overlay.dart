import 'package:flutter/material.dart';
class RedAlertOverlay extends StatefulWidget {
  final String token; const RedAlertOverlay({super.key, required this.token});
  @override State<RedAlertOverlay> createState()=>_RedAlertOverlayState();
}
class _RedAlertOverlayState extends State<RedAlertOverlay> {
  int sec = 90;
  @override void initState(){ super.initState(); Stream.periodic(Duration(seconds: 1), (i)=>90-i).take(90).listen((s){ if(mounted) setState(()=>sec=s); }); }
  @override Widget build(BuildContext context) {
    return Material(color: Colors.red.withOpacity(0.9), child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text("SOS BHEJA GAYA", style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)), Text("Token: ${widget.token}"), SizedBox(height: 20), Text("$sec sec me cancel kar sakte ho"), SizedBox(height: 20), ElevatedButton(onPressed: ()=>Navigator.pop(context), child: Text("CANCEL"))])));
  }
}