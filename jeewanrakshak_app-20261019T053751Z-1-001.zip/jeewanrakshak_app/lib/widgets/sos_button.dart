import 'package:flutter/material.dart';
import '../services/sos_service.dart';
import 'red_alert_overlay.dart';

class SOSButton extends StatefulWidget { const SOSButton({super.key}); @override State<SOSButton> createState()=>_SOSButtonState(); }
class _SOSButtonState extends State<SOSButton> {
  bool _pressing=false;
  void _onLongPressStart(_) async { setState(()=>_pressing=true); await Future.delayed(Duration(seconds: 3)); if(_pressing){ String token = await SOSService().triggerSOS(triggerType: 'button'); if(mounted) showDialog(context: context, builder: (_)=>RedAlertOverlay(token: token)); } }
  @override Widget build(BuildContext context) {
    return GestureDetector(
      onLongPressStart: _onLongPressStart,
      onLongPressEnd: (_)=>setState(()=>_pressing=false),
      child: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.red, Colors.black]), shape: BoxShape.circle), width: 200, height: 200, child: Center(child: Text("SOS\n3 Sec Dabao", textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))),
    );
  }
}