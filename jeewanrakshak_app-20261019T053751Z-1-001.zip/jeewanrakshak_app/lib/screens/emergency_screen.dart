import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class EmergencyScreen extends StatelessWidget {
  final bool isWomenSafety;
  const EmergencyScreen({super.key, this.isWomenSafety = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(isWomenSafety ? "Women Safety" : "Emergency")),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          if(isWomenSafety) Container(color: Colors.pink.withOpacity(0.2), padding: EdgeInsets.all(12), child: Text("You are in Women Safety Mode. Shake phone to trigger SOS", style: TextStyle(color: Colors.pink))),
          _tile("Police", "112", Icons.local_police),
          _tile("Women Helpline", "1091", Icons.female),
          _tile("Ambulance", "108", Icons.medical_services),
          Divider(),
          ElevatedButton.icon(onPressed: () => launchUrl(Uri.parse("tel:911234567890")), icon: Icon(Icons.call), label: Text("Fake Call from Papa (Safety Trick)")),
        ],
      ),
    );
  }
  Widget _tile(String name, String no, IconData icon) => ListTile(leading: Icon(icon), title: Text(name), subtitle: Text(no), trailing: IconButton(icon: Icon(Icons.call, color: Colors.red), onPressed: () => launchUrl(Uri.parse("tel:$no"))));
}