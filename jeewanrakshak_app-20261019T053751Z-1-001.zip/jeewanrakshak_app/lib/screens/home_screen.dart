import 'package:flutter/material.dart';
import 'ask_help_screen.dart';
import 'do_help_screen.dart';
import 'emergency_screen.dart';
import '../services/women_safety_service.dart';
import 'jeewanrakshak_app/widgets/sos_button.dart';
import '../services/sos_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  int idx = 1;
  final pages = const [DoHelpScreen(), AskHelpScreen(), EmergencyScreen()];

  @override
  void initState() {
    super.initState();
    WomenSafetyService().startShakeSOS();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[idx],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: idx,
        onTap: (i) => setState(() => idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.volunteer_activism), label: "Do Help"),
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.emergency), label: "Emergency"),
        ],
      ),
      floatingActionButton: idx == 1? FloatingActionButton.extended(
        backgroundColor: const Color(0xFFD50000),
        onPressed: () => SOSService().triggerSOS(triggerType: 'women_safety'),
        icon: const Icon(Icons.woman),
        label: const Text("WOMEN SOS"),
      ) : null,
    );
  }
}