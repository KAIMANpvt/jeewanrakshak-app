import 'package:flutter/material.dart';
import '../services/sos_service.dart';

class AskHelpScreen extends StatefulWidget {
  const AskHelpScreen({super.key});
  @override
  State<AskHelpScreen> createState() => _AskHelpScreenState();
}

class _AskHelpScreenState extends State<AskHelpScreen> {
  String type = 'medical';
  bool isLoading = false; // FIX 1: Double click rokne ke liye

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Ask Help")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField(
              value: type, 
              items: [
                DropdownMenuItem(value: 'medical', child: Text("Medical")), 
                DropdownMenuItem(value: 'accident', child: Text("Accident")), 
                DropdownMenuItem(value: 'women_safety', child: Text("Women Safety"))
              ], 
              onChanged: (v)=>setState(()=>type=v!)
            ),
            SizedBox(height: 20),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, 
                minimumSize: Size(double.infinity, 60)
              ), 
              // FIX 2: Tera purana onPressed me await nahi tha, isliye City detect hone se pehle hi SnackBar aa jata tha
              onPressed: isLoading ? null : () async {
                setState(()=> isLoading = true);
                try {
                  // Tera purana logic - same to same
                  await SOSService().triggerSOS(type: type); 
                  
                  if(!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("$type SOS Sent! City Auto-Detected"))
                  );
                } catch (e) {
                  if(!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Error: $e"))
                  );
                } finally {
                  if(mounted) setState(()=> isLoading = false);
                }
              }, 
              child: isLoading 
                ? CircularProgressIndicator(color: Colors.white)
                : Text("SEND $type SOS", style: TextStyle(fontSize: 20))
            ),
          ],
        ),
      ),
    );
  }
}