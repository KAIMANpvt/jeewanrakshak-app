import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/sos_service.dart';
import '../services/location_service.dart';
import 'package:geolocator/geolocator.dart';

class DoHelpScreen extends StatefulWidget {
  const DoHelpScreen({super.key});

  @override
  State<DoHelpScreen> createState() => _DoHelpScreenState();
}

class _DoHelpScreenState extends State<DoHelpScreen> {
  Position? myPos;
  final currentUserId = Supabase.instance.client.auth.currentUser?.id; // FIX 1: Own ID

  @override
  void initState() {
    super.initState();
    _getMyLocation();
  }

  Future<void> _getMyLocation() async {
    try {
      // FIX 2: Dono naam support karega - crash nahi hoga
      final pos = await LocationService().getCurrentLocation();
      setState(() => myPos = pos);
    } catch (e) {
      print("Location error: $e");
      // Fallback try
      try {
        final pos = await LocationService().getLocation();
        setState(() => myPos = pos);
      } catch (e2) {
        print(e2);
      }
    }
  }

  String getDistance(double lat, double lon) {
    if (myPos == null) return "... km";
    double dist = Geolocator.distanceBetween(myPos!.latitude, myPos!.longitude, lat, lon);
    return "${(dist / 1000).toStringAsFixed(1)} km away";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Do Help - Nearby Alerts (2KM)"),
        backgroundColor: const Color(0xFF121212),
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: Supabase.instance.client
           .from('sos_requests')
           .stream(primaryKey: ['id'])
           .order('created_at', ascending: false),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.volunteer_activism, size: 80, color: Colors.grey),
                  SizedBox(height: 10),
                  Text("No alerts nearby", style: TextStyle(color: Colors.grey)),
                  Text("You are safe", style: TextStyle(color: Colors.grey, fontSize: 12)),
                ],
              ),
            );
          }

          final alerts = snapshot.data!;

          // --- 2KM FILTER - TERA WAHI LOGIC SAME HAI ---
          final nearbyAlerts = alerts.where((item) {
            // FIX 1 ADDED: Apna khud ka SOS hata diya
            if (item['user_id'] == currentUserId) return false;

            if (item['latitude'] == null || item['longitude'] == null || myPos == null) return true;
            try {
              double lat = (item['latitude'] as num).toDouble();
              double lon = (item['longitude'] as num).toDouble();
              double dist = Geolocator.distanceBetween(myPos!.latitude, myPos!.longitude, lat, lon);
              return dist <= 2000; // 2KM - TERA WAHI FORMULA
            } catch (e) {
              return false;
            }
          }).toList();

          if (nearbyAlerts.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.check_circle, size: 80, color: Colors.green),
                  const SizedBox(height: 10),
                  const Text("2KM ke andar koi emergency nahi hai", style: TextStyle(fontWeight: FontWeight.bold)),
                  const Text("You are safe - 2KM filter working", style: TextStyle(color: Colors.grey, fontSize: 12)),
                  const SizedBox(height: 20),
                  ElevatedButton(onPressed: () => setState(() {}), child: const Text("Refresh")),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: nearbyAlerts.length,
            itemBuilder: (context, index) {
              final item = nearbyAlerts[index];
              final type = item['type']?? 'medical';
              final status = item['status']?? 'pending';
              final lat = (item['latitude']?? 0.0) as num;
              final lon = (item['longitude']?? 0.0) as num;
              final city = item['city']?? 'Unknown City'; // FIX 3: Auto city

              bool isWomen = type == 'women_safety';
              bool isAccident = type == 'accident';

              Color cardColor = isWomen
                 ? const Color(0xFFFFE4EC)
                  : isAccident
                     ? const Color(0xFFFFEBEE)
                      : const Color(0xFFFFF3E0);

              Color iconColor = isWomen
                 ? const Color(0xFFE91E63)
                  : isAccident
                     ? const Color(0xFFD50000)
                      : Colors.orange;

              String title = isWomen
                 ? "WOMEN IN DANGER!"
                  : isAccident
                     ? "ACCIDENT ALERT!"
                      : "MEDICAL HELP NEEDED";

              IconData icon = isWomen
                 ? Icons.female
                  : isAccident
                     ? Icons.car_crash
                      : Icons.medical_services;

              return Card(
                color: cardColor,
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                margin: const EdgeInsets.only(bottom: 12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(backgroundColor: iconColor, child: Icon(icon, color: Colors.white)),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: iconColor)),
                                // FIX 3: Distance + City
                                Text("${getDistance(lat.toDouble(), lon.toDouble())} • $city", style: const TextStyle(fontSize: 12, color: Colors.black54)),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: status == 'pending'? Colors.green : Colors.blue, borderRadius: BorderRadius.circular(10)),
                            child: Text(status, style: const TextStyle(color: Colors.white, fontSize: 10)),
                          )
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(backgroundColor: iconColor),
                              onPressed: () async {
                                String url = "https://www.google.com/maps/search/?api=1&query=$lat,$lon";
                                await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                              },
                              icon: const Icon(Icons.location_on, color: Colors.white),
                              label: const Text("Navigate", style: TextStyle(color: Colors.white)),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
                              onPressed: () async {
                                await SOSService().acceptSOS(item['id'].toString());
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("You are going to help! Location saved.")));
                                }
                              },
                              icon: const Icon(Icons.volunteer_activism, color: Colors.white),
                              label: const Text("I WILL HELP", style: TextStyle(color: Colors.white)),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}