import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'profile_setup_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phoneCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  bool loading = false;

  Future<void> login() async {
    setState(()=>loading=true);
    final supa = Supabase.instance.client;
    try {
      // Demo login - Supabase me phone ko email bana ke login
      String phone = phoneCtrl.text.trim();
      String email = "$phone@jeewanrakshak.app";
      // try signUp, if exists then signIn
      try {
        await supa.auth.signUp(password: "jeewan123", email: email);
      } catch(e) {
        await supa.auth.signInWithPassword(password: "jeewan123", email: email);
      }
      if(mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ProfileSetupScreen()));
    } catch(e){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error: $e")));
    }
    setState(()=>loading=false);
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFD50000), Colors.black])),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.health_and_safety, size: 100, color: Colors.white),
              SizedBox(height: 20),
              Text("JeewanRakshak", style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900)),
              SizedBox(height: 40),
              TextField(controller: nameCtrl, decoration: InputDecoration(labelText: "Naam", filled: true, fillColor: Colors.white10, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              SizedBox(height: 15),
              TextField(controller: phoneCtrl, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: "Phone Number", prefixText: "+91 ", filled: true, fillColor: Colors.white10, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
              SizedBox(height: 25),
              SizedBox(width: double.infinity, height: 55, child: ElevatedButton(onPressed: loading?null:login, child: loading?CircularProgressIndicator(color: Colors.white):Text("Shuru Karo", style: TextStyle(fontSize: 18)))),
            ]),
          ),
        ),
      ),
    );
  }
}