require('dotenv').config();
const express = require('express');
const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const app = express(); app.use(express.json());
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);

app.post('/send-sos', async (req,res)=>{
  const { city, token } = req.body;
  const { data: users } = await supabase.from('users').select('phone').eq('city', city).limit(10);
  if(!users || users.length==0) return res.json({sent:false});
  const numbers = users.map(u=>u.phone).join(',');
  await axios.post('https://www.fast2sms.com/dev/bulkV2',
    { route:'q', message:`JeewanRakshak ${token}: ${city} me madad chahiye. App kholo.`, language:'english', flash:0, numbers },
    { headers:{ authorization: process.env.FAST2SMS_KEY }}
  );
  res.json({sent:true, count: users.length});
});
app.listen(3000, ()=>console.log('Backend ON 3000'));