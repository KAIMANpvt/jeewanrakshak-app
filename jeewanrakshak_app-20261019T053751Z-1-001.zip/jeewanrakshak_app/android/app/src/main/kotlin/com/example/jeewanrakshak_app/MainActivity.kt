package com.example.jeewanrakshak_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
